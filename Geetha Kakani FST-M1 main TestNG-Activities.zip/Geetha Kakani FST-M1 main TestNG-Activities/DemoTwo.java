package suiteExample;
import org.testng.annotations.Test;

public class DemoTwo {
    @Test
    public void TestCase() {
        System.out.println("I'm in the test case from DemoTwo Class");
    }
}
